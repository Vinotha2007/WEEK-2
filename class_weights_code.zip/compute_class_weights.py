
import numpy as np
from sklearn.utils.class_weight import compute_class_weight

# Sample placeholders (you must define `train_ds` and `class_names` in real usage)
# For this example, we assume `train_ds` is a tf.data.Dataset or similar iterable
# and `class_names` is a list of class names (e.g., ['cat', 'dog', 'bird'])

class_counts = {i: 0 for i in range(len(class_names))}
all_labels = []

for images, labels in train_ds:
    for label in labels.numpy():
        class_counts[label] += 1
        all_labels.append(label)

# Compute class weights (index aligned)
class_weights_array = compute_class_weight(
    class_weight='balanced',
    classes=np.arange(len(class_names)),
    y=all_labels
)

# Create dictionary mapping class index to weight
class_weights = {i: w for i, w in enumerate(class_weights_array)}

# ✅ Optional: print results
print("Class Counts:", class_counts)
print("Class Weights:", class_weights)
